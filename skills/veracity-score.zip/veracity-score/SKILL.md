---
name: veracity-score
description: Audita la trazabilidad de afirmaciones en textos científicos, clínicos y regulatorios contra documentos aportados y, solo cuando esté autorizado, fuentes externas actuales. Úsala cuando el usuario pida Veracity Score, verificar, validar, revisar exactitud, fact-check, detectar afirmaciones sin soporte, contrastar un resumen generado por IA o ejecutar /veracity-score. Puede trabajar en modo documental, externo o híbrido. No la uses para sustituir la revisión médica, estadística, legal o regulatoria humana, emitir recomendaciones clínicas ni autorizar la divulgación de datos confidenciales.
---

# VERACITY SCORE

Auditar afirmaciones de alto impacto sin prometer “cero alucinaciones”. Medir la trazabilidad de la evidencia, no una verdad absoluta.

## Flujo

### 1. Aplicar la puerta de datos

Determinar si el material contiene datos personales, datos de pacientes, información confidencial, propiedad intelectual o documentación interna.

- Si el entorno no está aprobado para ese nivel de información, detener el análisis y pedir una versión pública, ficticia, anonimizada o autorizada.
- No enviar texto sensible a búsquedas externas ni usarlo como consulta web.
- Recordar que desactivar el entrenamiento en una cuenta personal no equivale a autorización corporativa.

### 2. Fijar el encargo

Inferir, o preguntar solo si es imprescindible:

- Uso previsto: nota personal, presentación interna, documento de trabajo o material regulatorio.
- Modo de verificación:
  - `DOCUMENTAL`: usar únicamente los archivos aportados.
  - `EXTERNO`: contrastar con fuentes públicas actuales.
  - `HÍBRIDO`: verificar primero contra los archivos y después contra fuentes externas autorizadas.
- Alcance: texto completo, afirmaciones críticas o una sección concreta.

Usar `DOCUMENTAL` por defecto cuando el usuario entregue un protocolo, informe o dossier y no solicite búsqueda externa.

### 3. Atomizar las afirmaciones

Separar cada afirmación factual verificable. Marcar como `CRÍTICA` cualquier afirmación sobre dosis, pauta, población, elegibilidad, tamaño muestral, endpoint, efecto, intervalo de confianza, valor p, seguridad, contraindicación, aprobación, obligación regulatoria, fecha vigente o relación causal.

No mezclar dos afirmaciones en una misma fila. Mantener el texto original para que la auditoría sea reproducible.

### 4. Buscar la evidencia

En modo documental:

- Localizar sección, tabla, figura y página.
- Incluir un pasaje exacto breve que sostenga la conclusión.
- Si no aparece, escribir `No consta en las fuentes aportadas`.
- No completar huecos con memoria o conocimiento general.

En modo externo o híbrido:

- Buscar activamente; no verificar desde memoria.
- Priorizar documentos regulatorios, registros oficiales, guías vigentes, publicaciones revisadas por pares y fuentes primarias.
- Comprobar fecha, versión, población, comparador, endpoint y magnitud; una coincidencia temática no basta.
- Tratar varios artículos que remiten al mismo estudio como una sola base de evidencia.
- Separar publicación revisada, preprint, abstract de congreso y nota de prensa.

### 5. Clasificar sin falsa precisión

Asignar uno de estos estados:

- `VERIFICADA`: la evidencia sostiene la afirmación completa.
- `PARCIAL`: sostiene solo una parte o exige una redacción más estrecha.
- `SIN SOPORTE`: no se encontró evidencia suficiente.
- `CONTRADICHA`: una fuente adecuada afirma lo contrario.
- `NO VERIFICABLE`: falta acceso, contexto, versión o fuente necesaria.
- `FUERA DE ALCANCE`: no es una afirmación factual o queda fuera del encargo.

No tratar `SIN SOPORTE` como `CONTRADICHA`.

Calcular, si el usuario quiere una cifra, un `ÍNDICE DE TRAZABILIDAD`, nunca un “porcentaje de verdad”. Leer `references/rubric.md` antes de puntuar.

### 6. Hacer una segunda pasada escéptica

Revisar las afirmaciones críticas buscando:

- extrapolaciones entre poblaciones;
- causalidad inferida desde asociación;
- cifras correctas con denominador, unidad o periodo equivocado;
- resultados secundarios presentados como primarios;
- aprobaciones, guías o requisitos desactualizados;
- citas que no sostienen exactamente la frase.

### 7. Entregar el informe

Usar esta estructura:

1. **Veredicto ejecutivo**: `PASA A REVISIÓN HUMANA`, `REVISAR ANTES DE CONTINUAR` o `NO LIBERAR`.
2. **Índice de trazabilidad** si procede, aclarando qué mide.
3. **Alertas críticas** en orden de riesgo.
4. **Registro de afirmaciones** con columnas: Nº, afirmación, criticidad, evidencia, localización/enlace, estado y corrección propuesta.
5. **Vacíos y límites**: fuentes ausentes, paywalls, versiones o fechas no confirmadas.
6. **Acciones siguientes**: conservar, estrechar, eliminar, verificar con SME o pedir material adicional.

Para material clínico o regulatorio, cerrar siempre con: `Este informe apoya la revisión; no sustituye la validación médica, bioestadística, legal ni regulatoria requerida.`

## Reglas no negociables

- No inventar fuentes, páginas, DOI, citas, datos ni enlaces.
- No afirmar que una revisión es “hallucination-free”.
- No cambiar la puntuación para satisfacer al usuario; cambiar la evidencia o la redacción.
- No declarar un material “listo para presentar o enviar” sin la puerta de revisión humana.
- Si dos fuentes fiables discrepan, mostrar el conflicto y explicar la diferencia de fecha, población, método o jurisdicción.
- Mantener separadas evidencia, inferencia y recomendación.

## Recursos

- Leer `references/rubric.md` para calcular criticidad e índice de trazabilidad.
- Leer `references/test-cases.md` únicamente al crear, actualizar o evaluar esta skill.
