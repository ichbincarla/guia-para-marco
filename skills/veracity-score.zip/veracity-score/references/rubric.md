# Rúbrica VERACITY SCORE

## 1. Peso por criticidad

| Nivel | Peso | Ejemplos |
|---|---:|---|
| Crítica | 3 | Dosis, pauta, seguridad, elegibilidad, endpoint, efecto, IC, p, aprobación o requisito regulatorio |
| Importante | 2 | Interpretación principal, fecha relevante, comparación, limitación que cambia la decisión |
| Contextual | 1 | Antecedente descriptivo que no cambia la decisión |

## 2. Crédito por estado

| Estado | Crédito |
|---|---:|
| VERIFICADA | 1,0 |
| PARCIAL | 0,5 |
| SIN SOPORTE | 0 |
| CONTRADICHA | 0 |
| NO VERIFICABLE | 0 |
| FUERA DE ALCANCE | Excluir |

Índice de trazabilidad = `100 × suma(peso × crédito) / suma(pesos evaluables)`.

Mostrar además el resultado de las afirmaciones críticas por separado. Un índice global alto no compensa una dosis, contraindicación o requisito regulatorio contradicho.

## 3. Puerta de salida

- `PASA A REVISIÓN HUMANA`: no hay afirmaciones críticas contradichas o sin soporte; las parciales están señaladas y corregidas.
- `REVISAR ANTES DE CONTINUAR`: existe al menos una afirmación crítica parcial o no verificable, o varias importantes sin soporte.
- `NO LIBERAR`: existe una afirmación crítica contradicha, una cita fabricada, una fuente inexistente o una inferencia presentada como dato.

Estas etiquetas son una puerta de calidad interna, no aprobación médica, legal ni regulatoria.

## 4. Jerarquía orientativa de evidencia externa

1. Texto regulatorio, etiqueta, evaluación o comunicación oficial vigente.
2. Registro oficial de ensayo y protocolo/resultados vinculados.
3. Guía clínica vigente de una sociedad reconocida.
4. Publicación primaria revisada por pares.
5. Revisión sistemática o metaanálisis adecuado a la pregunta.
6. Abstract de congreso, preprint o nota de prensa, siempre etiquetado.
7. Fuente terciaria únicamente como pista para localizar la fuente primaria.

La jerarquía no sustituye la pertinencia: una fuente de alto nivel sobre otra población no verifica la afirma