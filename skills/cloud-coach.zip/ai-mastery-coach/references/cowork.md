# Cowork Mastery (sources: claude.com/product/cowork, claude.com/blog/best-practices-for-getting-started-with-claude-cowork)

## What Cowork is

Anthropic's agentic assistant for non-developers: the same architecture behind Claude Code wrapped in an app anyone can use. Runs on web, desktop, mobile (beta). Generally available since 2026; included in Pro, Max, Team, Enterprise. It reads/writes local folders, uses connectors, runs long unattended tasks, schedules recurring work, and parallelizes via subagents. Cowork consumes usage limits faster than Chat.

## Task design — the skill that matters most

- **Describe outcomes, not step-by-step instructions.** "Turn this folder of interview notes into a themed findings doc with quotes" beats a 12-step procedure. Claude plans the steps.
- Best-fit tasks: multiple input files/folders + a shareable deliverable out (doc, deck, spreadsheet, cleaned dataset, organized folder).
- Attach the right folders and connectors BEFORE starting; missing access is the #1 cause of stalled tasks.
- Review outputs like a manager reviewing a junior's work: check the deliverable, not every step.
- Include success criteria in the ask: audience, format, length, what "done" looks like.
- For long tasks: let it run; steer from mobile; deletion always requires approval; Claude shows plans before significant actions.

## Plugins

A plugin packages skills + connectors + subagents + slash commands + hooks in one install. Anthropic open-sourced ~11 role plugins (sales, finance, legal, marketing, HR, engineering, design, operations, data). Enterprise admins can run private plugin marketplaces. Coaching move for teams: install the department plugin on day 1 and run its flagship skill as the first experience.

## Skills in Cowork

Same SKILL.md standard as everywhere. Users build custom skills for recurring deliverables (brand voice, report formats, CV tailoring, research dossiers). The trigger heuristic: third time doing the same multi-step task → make it a skill. Skills are managed in Settings > Capabilities.

## Scheduled tasks

Any cadence (daily/weekly/monthly) unattended: morning briefings, inbox digests, weekly status reports, market scans. Pattern: run the task once interactively, refine, then schedule the refined prompt.

## Connectors

Hundreds via MCP (Gmail, Calendar, Slack, Notion, Asana, Linear, Jira, Salesforce…). Local file access means a connector can save fetched data locally or use local files as input. Minimum-permissions habit: connect only what the task needs.

## Chat vs Cowork decision

Question/brainstorm/single doc → Chat. Whole task with a deliverable, multiple files, actions in apps, or recurring schedule → Cowork. If the user keeps copy-pasting file contents into chat, they should be in Cowork.

## Team rollout notes (from Anthropic's enterprise guidance)

Start pilots with 3–5 already-curious people who become champions; curate first experiences toward high-value use cases; enable connectors early; bake into new-hire onboarding (install app → authenticate connectors → install department plugin → run flagship skill); phase rollouts with retrospectives; sustained visible executive sponsorship.
