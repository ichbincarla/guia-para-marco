# Primary Sources Map — fetch these live when the distilled references aren't enough

The other reference files are distillations. This file is the full-depth layer: every primary source behind them, organized by topic. When a question needs more detail than the references hold — exact steps, full curricula, verbatim policy language, a current number — fetch the relevant URL(s) below with web fetch/search BEFORE answering. Always prefer these official sources over memory. If a URL has moved, search the domain for the title.

## Official documentation (docs.claude.com / platform.claude.com)

- Prompting best practices (canonical, model-specific + general): https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices
- Prompt engineering overview: https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/overview
- Prompting Claude Fable 5 (frontier-model deltas): https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/prompting-claude-fable-5
- Models overview (lineup, pricing, context, cutoffs): https://platform.claude.com/docs/en/about-claude/models/overview
- Reduce hallucinations: https://platform.claude.com/docs/en/test-and-evaluate/strengthen-guardrails/reduce-hallucinations
- Prompt caching (pricing multipliers, breakpoints, traps): https://platform.claude.com/docs/en/build-with-claude/prompt-caching
- Agent Skills overview (SKILL.md spec, progressive disclosure, security): https://docs.claude.com/en/docs/agents-and-tools/agent-skills/overview
- Claude Code best practices (the canonical engineering guide): https://code.claude.com/docs/en/best-practices
- Claude Code hooks guide: https://code.claude.com/docs/en/hooks-guide
- Developer docs root: https://platform.claude.com/docs

## Engineering canon (deep technique articles)

- Building Effective Agents (workflow patterns, agent design): https://www.anthropic.com/engineering/building-effective-agents
- Contextual Retrieval (RAG done right): https://www.anthropic.com/news/contextual-retrieval
- Model Context Protocol announcement: https://www.anthropic.com/news/model-context-protocol
- MCP spec/quickstarts: https://modelcontextprotocol.io
- Agent Skills open standard: https://agentskills.io
- Cookbook notebooks (agents, evals, vision, RAG, caching): https://github.com/anthropics/anthropic-cookbook
- Interactive courses repo (prompt-engineering tutorial, evals, tool use): https://github.com/anthropics/courses
- Prompt injection defenses research: https://www.anthropic.com/research/prompt-injection-defenses

## Anthropic Academy — all 20 course pages (anthropic.skilljar.com)

Hub: https://www.anthropic.com/learn · Catalog: https://anthropic.skilljar.com/
- Claude 101: https://anthropic.skilljar.com/claude-101
- Introduction to Claude Cowork: https://anthropic.skilljar.com/introduction-to-claude-cowork
- AI Capabilities and Limitations: https://anthropic.skilljar.com/ai-capabilities-and-limitations
- Claude Code 101: https://anthropic.skilljar.com/claude-code-101
- Claude Code in Action: https://anthropic.skilljar.com/claude-code-in-action
- Introduction to Agent Skills: https://anthropic.skilljar.com/introduction-to-agent-skills
- Introduction to Subagents: https://anthropic.skilljar.com/introduction-to-subagents
- Claude Platform 101: https://anthropic.skilljar.com/claude-platform-101
- Building with the Claude API: https://anthropic.skilljar.com/claude-with-the-anthropic-api
- Intro to MCP: https://anthropic.skilljar.com/introduction-to-model-context-protocol
- MCP Advanced Topics: https://anthropic.skilljar.com/model-context-protocol-advanced-topics
- Claude with Amazon Bedrock: https://anthropic.skilljar.com/claude-in-amazon-bedrock
- Claude with Google Vertex AI: https://anthropic.skilljar.com/claude-with-google-vertex
- AI Fluency Framework & Foundations: https://anthropic.skilljar.com/ai-fluency-framework-foundations
- AI Fluency for Educators: https://anthropic.skilljar.com/ai-fluency-for-educators
- AI Fluency for Students: https://anthropic.skilljar.com/ai-fluency-for-students
- Teaching AI Fluency (train-the-trainer): https://anthropic.skilljar.com/teaching-ai-fluency
- AI Fluency for Nonprofits: https://anthropic.skilljar.com/ai-fluency-for-nonprofits
- AI Fluency for Small Businesses: https://anthropic.skilljar.com/ai-fluency-for-small-businesses
- AI Fluency for Builders: https://anthropic.skilljar.com/ai-fluency-for-builders

Learn-hub tracks: https://www.anthropic.com/learn/build-with-claude · https://www.anthropic.com/learn/claude-for-work · https://www.anthropic.com/learn/claude-for-you
AI Fluency framework (open educational resource, full 4D sub-competencies): https://aifluencyframework.org · https://ringling.libguides.com/ai/framework

## Tutorials library (claude.com/resources/tutorials)

Index: https://claude.com/resources/tutorials
- Choosing between Claude Cowork or Chat: https://claude.com/resources/tutorials/choosing-between-claude-cowork-or-chat
- Using Cowork for your small business (4 plugin workflows, full prompts): https://claude.com/resources/tutorials/using-claude-for-your-small-business
- Delegating your first task in Cowork: https://claude.com/resources/tutorials/delegating-your-first-task-in-claude-cowork
- Getting started with Claude.ai: https://claude.com/resources/tutorials/getting-started-with-claude-ai
- Using Research: https://claude.com/resources/tutorials/using-research
- Get the most from recent Opus models: https://claude.com/resources/tutorials/get-the-most-from-claude-opus-4-6
- Getting the most out of Sonnet in Claude.ai: https://claude.com/resources/tutorials/getting-the-most-out-of-sonnet-4-5-in-claude-ai
- Role video series: Claude for Marketing / Sales / Engineering / HR / Product Management (search the tutorials index)
- Enterprise admin guide: https://claude.com/resources/tutorials/claude-enterprise-administrator-guide
- Scaling Cowork at your organization: https://claude.com/resources/tutorials/scaling-workflows-with-claude-cowork-at-your-organization

## Help center (support.claude.com) — features, plans, limits

- What are Projects: https://support.claude.com/en/articles/9517075
- What are Artifacts: https://support.claude.com/en/articles/9487310
- What are Skills: https://support.claude.com/en/articles/12512176 (using: 12512180 · creating custom: 12512198)
- Connectors: https://support.claude.com/en/articles/11176164 · directory: https://claude.ai/directory
- Memory: https://support.claude.com/en/articles/11817273
- Web search vs extended thinking vs Research: https://support.claude.com/en/articles/11095361
- Usage limits by plan (CHECK LIVE — changes often): https://support.claude.com/en/articles/9797557
- Using Cowork safely: https://support.claude.com/en/articles/13364135
- Plugins in Claude: https://support.claude.com/en/articles/13837440
- Claude Code power-user tips: https://support.claude.com/en/articles/14554000
- Privacy/data training policy: https://privacy.claude.com/en/articles/7996885

## Products, pricing, models (marketing pages — check live for current claims)

- Pricing: https://claude.com/pricing
- Cowork: https://claude.com/product/cowork · plugins blog: https://claude.com/blog/cowork-plugins
- Cowork getting-started best practices: https://claude.com/blog/best-practices-for-getting-started-with-claude-cowork
- Model pages: https://www.anthropic.com/claude/fable · /mythos · /opus · /sonnet · /haiku
- Fable 5 / Mythos 5 launch: https://www.anthropic.com/news/claude-fable-5-mythos-5

## Evidence base — customer stories & research

Directory (filter by industry/product/size): https://claude.com/customers · use-case library: https://claude.com/resources/use-cases
Key stories: /customers/novo-nordisk · /customers/harvey · /customers/rakuten · /customers/telus · /customers/jamf (whole-company adoption template) · /customers/advantage-solutions · /customers/cox-and-accenture · /customers/hubspot · /customers/lg-cns · /customers/blank-metal-qa (small business) · /customers/pacific-community-ventures
- Financial services announcement (NBIM, Bridgewater, CBA): https://www.anthropic.com/news/claude-for-financial-services
- How Anthropic teams use Claude Code: https://claude.com/blog/how-anthropic-teams-use-claude-code
- How Anthropic uses Claude in Legal: https://claude.com/blog/how-anthropic-uses-claude-legal
- Claude Code expertise research (~400k sessions): https://www.anthropic.com/research/claude-code-expertise
- Productivity gains research (3.1h → 15min): https://www.anthropic.com/research/estimating-productivity-gains
- How AI is transforming work at Anthropic: https://www.anthropic.com/research/how-ai-is-transforming-work-at-anthropic

## Workshop pedagogy (third-party)

- Atlassian AI Training Workshop play (the 1-hour run-sheet source): https://www.atlassian.com/team-playbook/plays/ai-training-workshop
- DeepLearning.AI × Anthropic courses: https://www.deeplearning.ai/courses (filter: Anthropic)
- Coursera × Anthropic: https://www.coursera.org/partners/anthropic

## When to fetch vs when the references suffice

Fetch live for: any price, limit, plan detail, model name/date, feature availability; full course curricula beyond the module lists; verbatim policy or legal language; a customer metric you're about to quote externally; anything post-dating the July 2026 crawl. The distilled references suffice for: techniques, frameworks, selection heuristics, workshop design, coaching diagnostics.
