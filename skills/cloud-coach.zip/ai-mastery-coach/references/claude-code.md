# Claude Code Mastery (source: code.claude.com/docs/en/best-practices)

The organizing principle of everything below: **the context window fills fast, and performance degrades as it fills.** Context is the resource to manage.

## The core workflow: Explore → Plan → Code → Commit

- **Plan mode** (Shift+Tab) reads without changing anything — separates research from execution. "Letting Claude jump straight to coding can produce code that solves the wrong problem." Skip planning only for one-sentence-diff changes.
- Give specific context: reference files with `@`, paste screenshots (don't describe UIs), give URLs, pipe data (`cat error.log | claude`), describe symptom + likely location + what "fixed" looks like.
- Commit checkpoints often so you can revert.

## Give Claude a way to verify its work

"It's the difference between a session you watch and one you walk away from." Tests, a build, a screenshot comparison (Playwright MCP), a lint pass. Ask for evidence, not assertions of success. Verification can gate completion via Stop hooks or a verification subagent. Fresh-context reviewers beat self-review (the worker shouldn't grade its own work).

## CLAUDE.md — the highest-leverage file

Read at the start of every conversation. `/init` generates a starter.

- **Include**: bash commands Claude can't guess, code-style rules that differ from defaults, test instructions, repo etiquette, architecture decisions, env quirks, domain vocabulary, workflow rules ("always run tests before declaring done").
- **Exclude**: anything Claude can infer, standard conventions, frequently-changing info, tutorials.
- **Keep it short** (community norm: under ~200 lines). "Bloated CLAUDE.md files cause Claude to ignore your actual instructions." Test per line: would removing this cause mistakes?
- Locations: `~/.claude/CLAUDE.md` (global), `./CLAUDE.md` (repo, in git), `./CLAUDE.local.md` (personal, gitignored), parent/child dirs for monorepos. Supports `@path/file` imports; a common pattern keeps content in AGENTS.md (portable) with CLAUDE.md just importing it.

## Context management commands

- `/clear` between unrelated tasks. **Rule of thumb: after two failed corrections, /clear and rewrite the prompt** — don't keep correcting into a polluted context.
- `/compact <instructions>` for controlled compaction (proactively around 60–70% full).
- `Esc` stop; `Esc+Esc` or `/rewind` restore to a checkpoint; `/btw` for side questions that never enter history.
- Handoff technique between sessions: ask Claude for a dense summary of decisions/state/next steps; start fresh with it.

## Extending Claude Code

- **Skills**: SKILL.md in `.claude/skills/`; auto-applied or `/skill-name`. `disable-model-invocation: true` for side-effecting manual workflows.
- **Subagents**: `.claude/agents/`, isolated context and restricted tools. Use for noisy research, code review, parallel workstreams (git worktrees). Orchestrator pattern: lead agent decomposes, delegates, synthesizes.
- **Hooks**: deterministic scripts at workflow points (unlike advisory CLAUDE.md). "Run eslint after every file edit." Configure via `/hooks` or `.claude/settings.json`. Also the right tool to hard-block dangerous commands.
- **MCP servers**: `claude mcp add`. Community consensus: GitHub + Playwright + Context7 (live library docs — kills hallucinated APIs) cover ~80% of coding workflows.
- **Plugins**: `/plugin` marketplace; bundle skills, hooks, subagents, MCP servers in one install.
- **Headless**: `claude -p "prompt"` for CI/scripts; `--output-format json`; fan out across files with `--allowedTools` scoping.

## Permissions and safety

Auto mode (classifier blocks risky commands), `/permissions` allowlists, `/sandbox` for OS isolation. Prefer allowlists over `--dangerously-skip-permissions`.

## For non-engineers

Anthropic's own legal, marketing, and growth teams use Claude Code for bulk document processing, ad-hoc data analysis, workflow automation, and small internal tools — no engineering support. Patterns: work step-by-step (not one-shot), keep a CLAUDE.md with your domain vocabulary, paste screenshots, learn which tasks can run on auto-accept (from a clean git state, review the 80% solution) vs supervised.

## Common failure patterns

Kitchen-sink session (fix: /clear) · correcting over and over (fix: /clear + better prompt) · over-specified CLAUDE.md (fix: prune) · trust-then-verify gap (fix: always provide verification) · infinite exploration (fix: scope narrowly or delegate to subagents).

## Larger features

Let Claude interview you (AskUserQuestion) → write a self-contained SPEC.md → execute in a fresh session. Writer/Reviewer pattern with fresh contexts; adversarial review subagent that sees only the diff + criteria (tell it to flag only correctness/requirement gaps, or you get over-engineering).
