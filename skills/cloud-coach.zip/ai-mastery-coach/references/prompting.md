# Prompting Mastery (verified against docs.claude.com, July 2026)

Canonical source: platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices

## Before prompting: define success

Anthropic's own guidance: establish success criteria before tuning prompts. Some failures (latency, cost) are better solved by switching models than by prompting harder.

## Core techniques (all current models)

**1. Be clear and direct.** Treat Claude as "a brilliant but new employee who lacks context on your norms." Golden rule: show your prompt to a colleague with minimal context — if they'd be confused, Claude will be too. Number sequential steps. If you want above-and-beyond behavior, ask for it explicitly.

Bad: "Help me with this email."
Good: "Rewrite this email to a skeptical CFO. 120 words max. Lead with the cost savings. No exclamation marks."

**2. Add motivation/context.** Explaining WHY lets Claude generalize: "this will be read aloud, so avoid formatting." Current models perform better when they understand intent. Template: `I'm working on [larger task] for [who it's for]. They need [what the output enables]. With that in mind: [request].`

**3. Examples (multishot).** The most reliable way to steer format, tone, and structure. 3–5 examples, wrapped in `<example>` tags. Make them relevant (mirror the real use case), diverse (cover edge cases), and structured. You can ask Claude to critique your examples or generate more.

**4. XML tags.** Wrap each content type: `<instructions>`, `<context>`, `<data>`, `<examples>`. This is the most reliable way to keep pasted content from being confused with instructions. Nest when hierarchical.

**5. Role prompting.** One sentence in the system prompt or first message changes rigor and vocabulary: "You are a senior employment lawyer reviewing this for a small business owner."

**6. Long documents (20k+ tokens):** put the document at the TOP, query at the END (docs: up to 30% quality improvement on multi-document tasks). Wrap each doc in `<document>` tags with `<source>`. Ask Claude to extract relevant quotes first, then answer from the quotes.

**7. Tell Claude what TO do, not what to avoid.** "Write in flowing prose paragraphs" beats "don't use markdown." Match your prompt style to desired output — a markdown-heavy prompt yields markdown-heavy answers.

**8. Escape hatch (anti-hallucination #1).** "If you don't know or the document doesn't say, say so." Hallucinations spike when context is missing but an answer is demanded.

## Thinking and reasoning (2026 state)

- Current frontier models use **adaptive thinking** — the model decides how much to think, controlled by an `effort` parameter (low/medium/high/xhigh), not manual token budgets. `budget_tokens` and last-turn prefill return errors on Claude 4.6+ / Fable 5.
- In the chat apps, this is the extended-thinking / effort toggle.
- Manual chain of thought still works when thinking is off: "Think step by step in `<thinking>` tags, then answer in `<answer>` tags."
- Prefer general instructions over prescriptive step lists: "think thoroughly about edge cases" often beats a hand-written plan.
- Self-check pattern: "Before you finish, verify your answer against [criteria]."

## The iteration loop (what separates intermediate from power users)

Never accept draft #1. The mature loop:

1. Draft.
2. Adversarial critique — and de-sycophant it explicitly, because Claude softens feedback by default: "Be a harsh reviewer. Do not compliment. List only problems, ranked by severity." Other forms: "Steelman the strongest argument against this," pre-mortem ("assume this failed in 6 months; write the post-mortem").
3. Revise against the critique.

Limitation: self-critique shares the generator's blind spots. For high stakes, run the critique in a fresh conversation, or paste the source material in with it.

## Agentic prompting notes

- Be explicit to trigger action: "can you suggest changes" gets suggestions, not changes.
- Over-prompting backfires on 2026 models: "CRITICAL: you MUST" language causes overtriggering. Write "Use this when…" instead.
- Ground progress claims: "Before reporting progress, audit each claim against a tool result."
- Anti-overengineering: "Avoid over-engineering. Only make changes directly requested."
- Anti-hallucination for code/docs: "Never speculate about content you have not opened."

## Common prompt mistakes → fixes

| Mistake | Fix |
|---|---|
| Vague ask ("make this better") | State task, audience, format, length, success criteria |
| No context | Paste the actual data/doc/thread; Claude can't see your screen or files unless provided or connected |
| No examples for formatted/voiced output | Give 2–3 input→output pairs |
| Demanding answers with no escape hatch | Permit "I don't know"; require quotes from source for claims |
| One giant conversation | One task per conversation; performance degrades as context fills |
| Accepting draft #1 | Run the iteration loop above |
| Repeating the same setup daily | Encode it once: Project instructions, CLAUDE.md, a custom skill |

## Console tooling

The Claude Console (platform.claude.com) includes a prompt generator, templates with variables, and a prompt improver — worth pointing API users at.
