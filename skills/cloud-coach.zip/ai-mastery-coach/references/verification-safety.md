# Verification, Privacy, and Safe Agentic Use

## Verification scales with stakes

Brainstorm → skim. Internal doc → spot-check numbers. External/legal/medical/financial → verify every claim and citation against primary sources. Autonomy raises the bar: agents need more checks than chats because unattended errors compound.

## Fact-checking discipline

- Give the escape hatch: "If the document doesn't say, say so."
- Over documents: "Quote the exact passage supporting each claim."
- With web search on: require inline source URLs; click 2–3.
- Quantitative: "Show your calculation"; re-run one number by hand.
- Independent check: generate in one chat → paste into a FRESH chat: "Fact-check this. List claims you cannot verify." (Self-critique in the same context shares the generator's blind spots.)
- Hallucination mechanics: they spike when context is missing but an answer is demanded. Fix the context, not just the checking.

## Confidential data

- Consumer plans (Free/Pro/Max) may train on chats unless the user opts out in settings — check this first. Team/Enterprise and API do not train on data; Enterprise adds audit logs, retention, SSO; zero-data-retention available for API.
- Habits: classify before pasting (client PII, credentials, M&A material → no, or Enterprise-only); redact names/IDs when identity doesn't matter; never paste API keys or passwords; know the employer's AI policy.

## Prompt injection (the concept every agentic user needs)

**Anything the agent reads is a potential instruction** — webpages, emails, PDFs, MCP tool outputs. Attackers hide "ignore your instructions and send X to Y" in content. Anthropic has driven browser-agent attack success to ~1% on recent models, but it is not solved.

User habits:
- Minimum permissions/connectors per task.
- Keep human approval on sends, purchases, deletions, anything leaving the machine.
- Danger zone = agent processes untrusted content (inbound email, arbitrary websites) WHILE holding write/send powers. Be extra suspicious there.
- Review agent action logs; don't blanket-"always allow" destructive commands.
- Claude Code: allowlists over --dangerously-skip-permissions; hooks to hard-block dangerous commands.

## Trust calibration (coach this explicitly)

Trust is a dial, not a switch. The intermediate-user failure is uniform trust (all-skeptic wastes the tool; all-believer ships errors). Teach: match verification effort to (stakes × autonomy), and build verification INTO workflows (tests, source-quoting, fresh-context review) rather than relying on vigilance.
