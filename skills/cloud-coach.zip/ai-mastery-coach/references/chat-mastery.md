# Claude.ai Chat Mastery: Projects, Artifacts, Skills, Connectors, Memory

## Projects — the biggest jump most intermediate users never make

Projects organize related chats around a shared knowledge base that is ALWAYS loaded (static background knowledge).

- **Custom instructions** (~8,000 chars) = rules. **Knowledge files** (up to ~200K tokens) = reference. Don't put reference material in instructions.
- Short, specific directives beat explanatory paragraphs: "Use British English. Never use em dashes." > a paragraph on style philosophy.
- Negative instructions work well: list banned words, AI-ish phrasings, structures Claude should never use.
- Keep knowledge docs 1–3 pages each; dense and specific outperforms long dumps.
- Iterate: after 3–5 chats, fold recurring corrections back into the instructions. Improvements compound.
- One project per recurring workflow: "Weekly newsletter," "Grant proposals," "Client X," each with its own voice/context files.

## Artifacts

Standalone content windows for code, documents, and interactive apps (React, HTML, Mermaid, SVG; docx/pptx/xlsx/pdf via skills). Over half a billion created.

- Build interactive dashboards from an uploaded CSV — name the metrics, ranges, breakdowns.
- Screenshot-to-data: paste a screenshot of any table; Claude structures it.
- Publish/share by link (viewers need no account); others can remix.
- AI-powered artifacts can call Claude from inside the artifact; MCP + persistent storage let artifacts read/write tools like Asana, Calendar, Slack (Pro/Max/Team/Enterprise).

## Skills

Folders of instructions, scripts, and resources Claude loads dynamically via progressive disclosure (only name+description in context until relevant — many skills coexist cheaply).

- Types: Anthropic skills (Excel/Word/PowerPoint/PDF, auto-invoked), custom skills (markdown; no coding for simple ones), org-provisioned (Team/Enterprise), partner skills.
- **Skills vs Projects**: Projects = always-loaded static knowledge; Skills = task procedures that load on demand and work everywhere (chat, Code, Cowork).
- **Skills vs MCP**: MCP connects to tools; skills teach how to use them.
- Rule of thumb for users: the third time you paste the same instructions, turn them into a skill (or Project if chat-only and context-like).
- Open standard: agentskills.io.

## Connectors / MCP

The Connectors Directory (claude.ai/directory) catalogs MCP servers from Anthropic and third parties. Connectors let chat pull real context (Drive, Gmail, Calendar, Notion, Slack…) instead of the user pasting it. Coaching point: enabling one connector often removes the user's biggest daily friction (copy-pasting context in).

## Memory

Claude summarizes conversations and synthesizes insights across chat history, updated roughly every 24h. Users can import/export memories. Distinct from Project knowledge (curated) — memory is automatic.

## Search / Thinking / Research (when to toggle what)

- Web search → 1–2-lookup factual questions.
- Extended thinking → hard reasoning, no fresh info needed.
- Research → multi-minute, multi-source cited reports; pair with extended thinking.

## Personalization

Profile-level custom instructions apply to all conversations; **styles** control tone/format; project instructions override within a project. Layering: profile (who I am, global preferences) → project (this workflow's rules) → message (this task's specifics).
