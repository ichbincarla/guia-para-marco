# Industry Use Cases and Evidence (claude.com/customers — all metrics are company-reported; say so when quoting)

## Cross-industry case bank

**Healthcare/Pharma**
- Novo Nordisk: clinical study reports that took 40–50 people up to 15 weeks now drafted in minutes by ~3 people; ~90% cut in writing time, human review retained; regulator feedback positive.
- Banner Health: oncology record summarization from ~8h/patient to automatic; 1,400+ clinical notes processed [secondary source].

**Finance**
- NBIM (Norway's $1.7T sovereign fund): ~20% productivity gains ≈ 213,000 hours; portfolio managers query the data warehouse and analyze earnings calls in natural language.
- Bridgewater: Claude "with the precision of a junior analyst" — Python generation, data viz, iterative analysis.
- Commonwealth Bank of Australia: fraud prevention, customer service.

**Legal**
- Harvey: Claude powers its legal AI; Opus scored 90.9% on Harvey's BigLaw Bench; wins internal bake-offs on grounding and citation faithfulness.
- GC AI: 1,500 companies; claims lawyers save 14 h/week. Big Law firms (Freshfields, Quinn Emanuel, Holland & Knight) use Claude on live matters.
- Anthropic's own legal team: turned recurring pain points (marketing review, contract redlining) into repeatable workflows; framing = from "department of no" to thought partners.

**Retail / Services**
- Advantage Solutions (~70k employees): "gives frontline managers 70,000 hours back" with Enterprise + Code + Cowork.
- Blank Metal: small professional-services firm that "runs on Claude Cowork" — the small-business template.

**Marketing / Telecom**
- Cox Communications + Accenture: 7x first-year ROI; 55% faster speed-to-market; lead validation cost −86%, accuracy 18%→97%.
- HubSpot: cross-team usage, productivity lift up to 40% [secondary].
- Anthropic growth marketing: one person cut 2-hour ad-copy tasks to 15 min with subagents + a Figma workflow.

**Engineering / IT**
- Rakuten: Claude Code cut feature time-to-market 79% (24 days → 5).
- TELUS: 57,000 employees; 13,000+ custom AI solutions; code ships 30% faster.
- LG CNS: modernizing 20-year-old enterprise systems.

**Whole-company adoption exemplar**
- Jamf: 89% active usage among licensed employees within 8 weeks; 285 documented use cases across 16 departments (98 implemented); HR alone saves ~838 h/month. Best template for "how a whole company adopts Claude."

**Macro number**: Anthropic research estimates average task time drops from 3.1 hours to ~15 minutes with Claude (≈92% reduction) — anthropic.com/research/estimating-productivity-gains.

## What the evidence teaches (coaching distillations)

1. The winners turned one-off wins into systems: documented use cases, department plugins, internal skills, champions. Individual cleverness didn't scale; encoded workflows did.
2. Human review retained at the high-stakes end (Novo Nordisk, legal) — automation of drafting, not of accountability.
3. Domain expertise predicts success more than technical skill (Anthropic's ~400k-session Claude Code study): the human decides WHAT, the agent decides HOW; experts recover from errors faster.
4. Non-engineers build real tools (Anthropic legal/marketing) when given Code/Cowork plus permission to iterate.

## Use-case starter map by function (for workshops and "where do I start" questions)

- Sales: account research dossiers, call prep, follow-up drafting, pipeline hygiene reports.
- Marketing: campaign briefs, content in brand voice, competitor scans, performance report narration.
- Legal: NDA triage, contract review vs playbook, template responses, compliance checks.
- Finance: variance narratives, reconciliation prep, board-pack drafting, close checklists.
- HR/People: job descriptions, interview guides, policy Q&A, onboarding docs.
- Operations: SOP writing, process mapping, vendor comparisons, status reports.
- Engineering: code review, test generation, incident postmortems, migration scripts.
- Executives: meeting prep, decision memos, "steelman both sides," weekly synthesis digests.

Find more: claude.com/customers (filterable by industry/product/size) and claude.com/resources/use-cases.
