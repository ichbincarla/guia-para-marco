# Models, Plans, and Surface Selection (July 2026 snapshot — verify prices/limits before quoting)

## Current model lineup

A new "Mythos-class" tier now sits above Opus. Claude Fable 5 and Claude Mythos 5 (launched June 9, 2026) are the same underlying model; Fable carries additional safety measures for general availability, Mythos is restricted to approved organizations.

| Model | API ID | Best for | Price in/out per MTok | Context / max output |
|---|---|---|---|---|
| Claude Fable 5 | claude-fable-5 | Hardest problems, long-running agents, highest capability | $10 / $50 | 1M / 128k |
| Claude Opus 4.8 | claude-opus-4-8 | Complex agentic coding, enterprise work | $5 / $25 | 1M / 128k |
| Claude Sonnet 5 | claude-sonnet-5 | Default: best speed/intelligence balance | $3 / $15 (intro $2/$10 to Aug 31 2026) | 1M / 128k |
| Claude Haiku 4.5 | claude-haiku-4-5 | Fastest, cheapest near-frontier | $1 / $5 | 200k / 64k |

Knowledge cutoffs: Fable 5 / Opus 4.8 / Sonnet 5 ≈ Jan 2026; Haiku 4.5 ≈ Feb 2025.

Fable 5 specifics worth coaching on: adaptive thinking always on; runs longer turns by default (minutes at high effort); safety classifiers can fall back a request to Opus 4.8 (<5% of sessions, user is informed); instruction-following is strong enough that brief instructions beat exhaustive case enumeration — skills/prompts written for older models are often too prescriptive for it.

## Model tier heuristics

- **Haiku**: high-volume, latency-sensitive, simple — classification, routing, extraction, triage, batch summarization.
- **Sonnet**: the default for ~80% of daily work — writing, analysis, standard coding.
- **Opus**: escalation tier — multi-step reasoning, cross-file engineering, long-horizon planning, high-stakes accuracy.
- **Fable/Mythos-class**: the hardest unsolved problems, work that takes a person hours-to-weeks end to end.
- Key heuristic: **human-in-the-loop lets you downgrade a tier; autonomous loops make you upgrade a tier** (unattended errors compound).
- Cascade pattern (API): cheap model routes/triages; expensive model handles the hard 10%.
- Boris Cherny (Claude Code creator) heuristic [community-reported]: default to the stronger model — a weaker model needing more correction is slower overall.

## Plans (verify current numbers at support.claude.com before quoting)

- **Free**: basic access, lower limits. Skills available even on Free (needs code execution enabled).
- **Pro** (~$17/mo annual, $20 monthly): ~5x free usage; 5-hour session resets plus a weekly cap; includes Cowork.
- **Max 5x** ($100/mo) / **Max 20x** ($200/mo): 5x/20x Pro usage; two weekly limits (all-models + Sonnet-only).
- **Team** ($20/seat/mo, 5–75 seats): admin controls, Slack connector; extra usage at API rates.
- **Enterprise**: SSO, audit logs, retention controls, org-provisioned skills, private plugin marketplaces.
- Usage credits let paid users continue past limits at API rates. Cowork consumes limits faster than Chat.
- Consumer plans may train on chats unless the user opts out in settings; Team/Enterprise/API do not train on data.

## Surface selection (the question intermediate users get wrong most)

- **Chat**: fits in a few exchanges — question, explanation, brainstorm, single-document work.
- **Projects**: the same context reused across many chats — a client, a product, a voice. Instructions + knowledge persist. "Re-explaining the same context daily" is the signal to create one.
- **Cowork**: hand off a whole task with a deliverable — deck, cleaned spreadsheet, research synthesized from a folder + connectors, browser actions, scheduled recurring work. You review results, not steps.
- **Claude Code**: terminal, deepest control — codebases, scriptable automation, hooks, subagents, CI. Also excellent for technical-adjacent users doing bulk file processing.
- **API / Agent SDK**: anything repeated at scale, embedded in products, or needing zero-data-retention.

Decision shortcuts:
- Output is a conversation → Chat. Output is a file/deliverable → Cowork. Output is code in a repo → Code. Output is a product feature → API.
- Recurring context → Project (chat) or CLAUDE.md/skill (Code/Cowork).

## Feature-mode selection inside chat (official guidance)

- **Web search**: factual queries answerable in 1–2 lookups.
- **Extended thinking / effort**: complex reasoning needing no fresh info (math, debugging, analysis).
- **Research mode**: comprehensive gathering, 5+ tool calls over minutes, cited report. Combine with extended thinking for planning + execution.

## Adjacent products worth knowing

- **Claude in Chrome** (browsing agent), **Claude in Excel**, **Claude in Slack**.
- **Claude Science** (June 2026): research workbench with 60+ scientific databases.
- **Agent Skills open standard** (agentskills.io): the SKILL.md format works across Claude products and some third-party tools.
