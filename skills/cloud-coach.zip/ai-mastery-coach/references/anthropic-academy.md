# Anthropic Academy & Official Learning Catalog (deep-crawled from anthropic.com/learn, anthropic.skilljar.com, claude.com/resources/tutorials — July 2026)

Use this file to: prescribe learning paths, point users at the exact right free course, and mine curricula when designing workshops (the module lists below are proven course structures you can adapt).

Contents: §1 Course catalog (20 courses) · §2 Learning paths by profile · §3 Learn-hub guides (developer canon) · §4 Tutorial library highlights · §5 Facts for accurate answers

## §1 Course catalog — anthropic.skilljar.com (all FREE, no durations published)

### Fundamentals & everyday use
- **Claude 101** — everyday users; certificate. Modules: Meet Claude (first conversation, getting better results, desktop app: Chat/Cowork/Code) → Organizing work (Projects, Artifacts, Skills) → Expanding reach (connectors, enterprise search, Research mode) → Use cases by role → certificate. The default first course for any beginner.
- **Introduction to Claude Cowork** — "productive in your first week." Modules: Meet Cowork (setup, first task) → Make it yours (global instructions/projects, skills, plugins) → Claude in Chrome + Microsoft 365 → Sharing and safety (safe steering, validating skills, sharing with team) → quiz.
- **AI Capabilities and Limitations** — the "machine properties" companion to AI Fluency. Modules: What we mean by AI, how AI gets its character → Next-token prediction → Knowledge (where it fails) → Working memory (context window as limitation) → Steerability → When properties collide (diagnosing which kind of "unexpected" an output is). Excellent workshop source for teaching WHY Claude behaves as it does.

### Claude Code
- **Claude Code 101** — new-to-agents devs; prereq: editor + CLI basics. Modules: What is Claude Code (agentic loop, tools, permissions) → First prompt (install across terminal/VS Code/JetBrains/Desktop/web; approval modes, Plan Mode) → Daily workflows (explore→plan→code→commit; /compact /clear /context; code review) → Customizing (CLAUDE.md, subagents, skills, MCP, hooks).
- **Claude Code in Action** (flagship) — devs + teams; prereq: CLI, git. Modules: coding-assistant architecture → hands-on (setup, adding context, controlling context, custom commands, MCP servers, GitHub integration/automated review) → Hooks and the SDK (defining/implementing hooks, gotchas, useful hooks) → quiz.
- **Introduction to Agent Skills** — 6 lessons: skills vs CLAUDE.md/hooks/subagents → first SKILL.md (descriptions that trigger reliably) → multi-file skills + progressive disclosure + allowed-tools → choosing the right mechanism → sharing (repos, plugins, enterprise managed settings) → troubleshooting (won't trigger, priority conflicts).
- **Introduction to Subagents** — 4 lessons: separate context windows → creating via /agents → designing (structured outputs, obstacle reporting, limited tools) → when delegation helps + anti-patterns.

### Developer platform & API
- **Claude Platform 101** — TypeScript SDK; "bridge from a single request to a production agent." Modules: first API call, choosing the model → agent loop by hand then Tool Runner; tool use; thinking → extending (hosted tools, skills, MCP, context management past turn ten) → Managed Agents → building with Claude Code → quiz.
- **Building with the Claude API** — Python; the deepest course (11 modules): API operations → prompt evaluation (test datasets, model-based + code-based grading) → prompt engineering → full tool use → RAG & agentic search (chunking, embeddings, BM25, multi-index) → features (thinking, images, PDFs, citations, prompt caching, code execution, Files API) → MCP → Claude Code + computer use → agents vs workflows (parallelization, chaining, routing) → final assessment.
- **Intro to MCP** — Python; build servers/clients; the three primitives: tools (model-controlled), resources (app-controlled), prompts (user-controlled); server inspector.
- **MCP: Advanced Topics** — sampling, notifications, roots, transports (STDIO, StreamableHTTP), stateful vs stateless scaling.
- **Claude with Amazon Bedrock** / **Claude with Google Cloud's Vertex AI** — the API course adapted per cloud (Bedrock version adds reranking + contextual retrieval depth; born as AWS-employee accreditation).

### AI Fluency family (all variants require/recommend the core course first)
- **AI Fluency: Framework & Foundations** — everyone; certificate; by Profs. Feller (UCC) and Dakan (Ringling). Modules: why fluency → the 4D framework → Deep Dive 1: what is generative AI → Delegation → Description → Deep Dive 2: effective prompting → Discernment → the Description-Discernment loop → Diligence → certificate.
- **AI Fluency for Educators** (course design, learning materials/assignments) · **for Students** (AI as learning partner, career planning, being the human in the loop) · **Teaching AI Fluency** (train-the-trainer: the Delegation-Diligence and Description-Discernment loops as pedagogy; assessing the 4Ds; discipline adaptation) · **for Nonprofits** (with GivingTuesday; research/writing loops, privacy & data, workflow augmentation) · **for Small Businesses** (with PayPal; transparent AI use, human in the loop) · **for Builders** (with CodePath; discernment for code and UX; "stand behind what you build").

Design pattern to copy in workshops: Anthropic segments the SAME core framework by AUDIENCE, not difficulty.

## §2 Learning paths to prescribe

- **Complete beginner (any role):** Claude 101 → AI Fluency: Framework & Foundations → role variant if one fits.
- **Intermediate business user (the coach's main audience):** AI Capabilities and Limitations (mental model) → Intro to Claude Cowork → Intro to Agent Skills. Fill gaps with tutorials (§4).
- **Team lead rolling out Claude:** AI Fluency core → Teaching AI Fluency → this skill's workshops.md run-sheet; point champions at Claude 101.
- **Non-dev builder / power user:** AI Fluency for Builders → Claude Code 101 → Intro to Subagents.
- **Developer:** Claude Code in Action → Claude Platform 101 (TS) or Building with the Claude API (Python) → MCP intro → MCP advanced.
- **Educator:** AI Fluency for Educators → Teaching AI Fluency.

## §3 Learn-hub developer canon (anthropic.com/learn/build-with-claude)

- **Building Effective Agents** (anthropic.com/engineering/building-effective-agents): workflows (predefined code paths) vs agents (LLM directs its own tool use). Use the simplest thing that works; start with direct API calls, not frameworks. Five composable patterns: prompt chaining (sequential + gates), routing (classify → specialized prompt; cheap model for easy queries), parallelization (sectioning, voting), orchestrator-workers (dynamic subtasks), evaluator-optimizer (generator + critic loop). Agents = LLM + tools in a loop with environmental feedback; sandbox, stopping conditions, human checkpoints. Tool-interface design: formats close to training data, poka-yoke arguments (forcing absolute paths eliminated an error class).
- **Contextual Retrieval** (anthropic.com/news/contextual-retrieval): under ~200K tokens of knowledge → skip RAG, cache the whole prompt. Otherwise embeddings + BM25 rank fusion; prepend 50–100 tokens of situating context per chunk (generated by Haiku, ~$1.02/M doc tokens with caching); retrieval failures −49%, −67% with a reranker; pass top-20 chunks.
- **Prompt caching docs**: writes 1.25× (5-min) / 2× (1-hr), reads 0.1×; prefix order tools→system→messages; breakpoint must sit on the last block IDENTICAL across requests (timestamps upstream kill cache hits); min cacheable 1,024–4,096 tokens.
- **Agent Skills overview docs**: SKILL.md frontmatter (name ≤64 chars, description ≤1024 chars stating what AND when); three-level progressive disclosure (~100 tokens metadata / <5k body / resources on demand, scripts run via bash without entering context); audit third-party skills like software — external-fetching skills are riskiest.
- **MCP announcement + modelcontextprotocol.io**: open standard; pre-built servers (Drive, Slack, GitHub, Git, Postgres, Puppeteer); path = install pre-built → quickstart your own.
- Also on the hub: anthropic-cookbook notebooks (agents, evals, vision, RAG), github.com/anthropics/courses (interactive prompt-engineering tutorial, real-world prompting, prompt evaluations, tool use).

## §4 Tutorial library highlights (claude.com/resources/tutorials)

Substantive written playbooks (fetched):
- **Choosing between Claude Cowork or Chat**: Chat = one-off, thought-partnership, you assemble the output (serial); Cowork = clear deliverable touching files/tools, it assembles the output (parallel). Cowork loop: understand → plan (visible steps) → execute → verify → deliver, approval gates before consequential actions. Cowork-only: local folders, logged-in browser via Claude in Chrome, native apps via computer use, parallel subtasks, scheduled tasks, Dispatch from phone.
- **Using Claude Cowork for your small business**: four plugin workflows with full prompts — /monday-brief (QuickBooks + PayPal + HubSpot + calendar → ranked one-pager, schedulable), /run-campaign (weakest month → offer → Canva assets → staged send), /close-month (reconcile, flag mismatches, accountant-ready packet), /plan-payroll (30-day cash forecast, ranked overdue invoices, calibrated reminders). Principles: nothing sends/posts/pays without approval; skills persist corrections; Claude inherits only your existing permissions.
- **Get the most from recent Opus models**: say it once + explain intent (drop "remember to…" nagging); front-load files/links; skip "act as an expert" role-play for agents; set check-in points ("ask me before trying more than 2–3 approaches"); ask for three alternatives and "what's wrong with this plan?"; lead with a style sample for writing.
- **Getting the most out of Sonnet in Claude.ai**: for sustained tasks ask for a plan/checklist with success criteria first; explicitly ask for file-creation tools; request source verification; counter-instructions for quirks ("work on one thing at a time").
- Video series (3–7 min each, for pointing users at): Getting started with Claude.ai · Intro to Projects · Intro to Artifacts · Using Research · Claude for Marketing / Sales / Engineering / HR / Product Management · Delegating your first task in Cowork. Concept explainers: Why do AI models hallucinate? · What is sycophancy? · The 4 Ds — Behavioral Indicators.

## §5 Facts for accurate answers

- All Academy courses are free; certificates confirmed on: Claude 101, AI Fluency core + Educators + Students + Teaching (others end in quizzes).
- AI Fluency materials are CC BY-NC-SA — reusable in workshops with attribution, non-commercial caveat.
- The AI Fluency newsletter (quarterly) signup is on anthropic.com/learn.
- Hub structure: anthropic.com/learn → Build with Claude / Claude for Work / Claude for Personal; tutorials live at claude.com/resources/tutorials; support articles have migrated there.
